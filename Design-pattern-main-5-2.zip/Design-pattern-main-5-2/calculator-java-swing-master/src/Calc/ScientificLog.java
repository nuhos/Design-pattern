package Calc;

public class ScientificLog {
    public double log10(double a) {
        return Math.log10(a);
    }
}
