package Calc;

public class Subtraction implements appOperation {
    @Override
    public double calculate(double a, double b) {
        return a - b;
    }
}
