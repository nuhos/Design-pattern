package Calc;

public class Multiplication implements appOperation {
    @Override
    public double calculate(double a, double b) {
        return a * b;
    }
}
