package Calc;

public class ScientificPower {
    public double pow(double base, double exponent) {
        return Math.pow(base, exponent);
    }
}
