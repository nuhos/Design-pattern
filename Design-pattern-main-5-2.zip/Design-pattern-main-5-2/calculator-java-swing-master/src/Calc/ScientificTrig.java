package Calc;

public class ScientificTrig {
    public double sinDeg(double degrees) {
        return Math.sin(Math.toRadians(degrees));
    }
    public double cosDeg(double degrees) {
        return Math.cos(Math.toRadians(degrees));
    }
}
