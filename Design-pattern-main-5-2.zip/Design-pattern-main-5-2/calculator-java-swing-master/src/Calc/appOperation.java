package Calc;

public interface appOperation {
    double calculate(double a, double b);
}

